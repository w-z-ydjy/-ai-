/* ============================================================
   智慧党建平台 - 共享JavaScript文件
   ============================================================ */

/* Toast */
function showToast(msg, type = 'success') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.className = 'toast-' + type;
  toast.style.display = 'block';
  setTimeout(() => { toast.style.display = 'none'; }, 3000);
}

/* Navigation */
function updateNavigation() {
  const loggedIn = localStorage.getItem('userLoggedIn') === 'true';
  const userName = localStorage.getItem('userName');
  const navRight = document.getElementById('navRight');
  
  if (navRight && loggedIn) {
    const loginBtn = navRight.querySelector('.nav-btn-login');
    const adminBtn = navRight.querySelector('.nav-btn-admin');
    
    if (loginBtn) {
      loginBtn.textContent = '👤 ' + userName;
      loginBtn.onclick = () => window.location.href = 'profile.html';
    }
    
    if (adminBtn) {
      const role = localStorage.getItem('userRole');
      adminBtn.style.display = (role === 'admin') ? 'inline-flex' : 'none';
    }
  }
}

/* Theme */
function toggleTheme() {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  
  body.classList.toggle('dark-theme');
  const isDark = body.classList.contains('dark-theme');
  
  if (themeToggle) {
    themeToggle.textContent = isDark ? '☀️ 浅色' : '🌙 深色';
  }
  
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  showToast(isDark ? '🌙 已切换到深色主题' : '☀️ 已切换到浅色主题');
}

function initTheme() {
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-theme');
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) themeToggle.textContent = '☀️ 浅色';
  }
}

/* Navbar scroll effects */
function initNavbarEffects() {
  const navbar = document.getElementById('topnav');
  if (!navbar) return;
  
  window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });
}

/* Mobile nav */
function toggleMobileNav() {
  const nav = document.getElementById('mobileNav');
  if (nav) nav.classList.toggle('open');
}

/* Font size */
function changeFontSize(action) {
  const root = document.documentElement;
  let currentSize = parseInt(localStorage.getItem('fontSize') || 16);
  
  switch (action) {
    case 'increase': currentSize = Math.min(currentSize + 2, 24); break;
    case 'decrease': currentSize = Math.max(currentSize - 2, 12); break;
    case 'reset': currentSize = 16; break;
  }
  
  root.style.setProperty('--font-size-base', currentSize + 'px');
  root.style.setProperty('--font-size-sm', (currentSize - 2) + 'px');
  root.style.setProperty('--font-size-lg', (currentSize + 2) + 'px');
  root.style.setProperty('--font-size-xl', (currentSize + 4) + 'px');
  root.style.setProperty('--font-size-2xl', (currentSize + 8) + 'px');
  
  localStorage.setItem('fontSize', currentSize);
  
  const currentFontSizeEl = document.getElementById('currentFontSize');
  if (currentFontSizeEl) currentFontSizeEl.textContent = currentSize;
  
  showToast(`字体大小已${action === 'increase' ? '增大' : action === 'decrease' ? '减小' : '重置'}`);
}

function initFontSize() {
  const savedSize = parseInt(localStorage.getItem('fontSize') || 16);
  const root = document.documentElement;
  root.style.setProperty('--font-size-base', savedSize + 'px');
  root.style.setProperty('--font-size-sm', (savedSize - 2) + 'px');
  root.style.setProperty('--font-size-lg', (savedSize + 2) + 'px');
  root.style.setProperty('--font-size-xl', (savedSize + 4) + 'px');
  root.style.setProperty('--font-size-2xl', (savedSize + 8) + 'px');
}

/* Search */
function performSearch() {
  const searchInput = document.getElementById('searchInput');
  const searchTerm = searchInput ? searchInput.value.trim() : '';
  
  if (!searchTerm) {
    showToast('请输入搜索关键词');
    return;
  }
  
  const searchData = [
    { title: '关于深入开展主题教育学习活动的通知', category: '通知', date: '2024-12-10' },
    { title: '人工智能协会2024年度党员发展大会圆满召开', category: '要闻', date: '2024-12-15' },
    { title: '社团党支部荣获"优秀党支部"称号', category: '荣誉', date: '2024-12-05' },
    { title: '第四季度预备党员宣誓仪式隆重举行', category: '活动', date: '2024-11-28' },
    { title: 'AI赋能党建：智慧党建平台建设工作汇报', category: 'AI党建', date: '2024-11-20' }
  ];
  
  const results = searchData.filter(item => {
    return item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
           item.category.toLowerCase().includes(searchTerm.toLowerCase());
  });
  
  showSearchResults(results, searchTerm);
}

function showSearchResults(results, searchTerm) {
  const modalContent = `
    <div class="search-results-modal">
      <div class="search-results-header">
        <h3>搜索结果："${searchTerm}"</h3>
        <button class="modal-close" onclick="closeSearchResults()">×</button>
      </div>
      <div class="search-results-body">
        ${results.length > 0 ? 
          results.map(item => `
            <div class="search-result-item">
              <div class="search-result-title">${item.title}</div>
              <div class="search-result-meta">
                <span class="tag tag-blue">${item.category}</span>
                <span>${item.date}</span>
              </div>
            </div>
          `).join('') : 
          '<div class="alert alert-info">未找到相关内容</div>'
        }
      </div>
    </div>
  `;
  
  const modalOverlay = document.createElement('div');
  modalOverlay.className = 'modal-overlay open';
  modalOverlay.id = 'searchResultsModal';
  
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.innerHTML = modalContent;
  
  modalOverlay.appendChild(modal);
  document.body.appendChild(modalOverlay);
  
  modalOverlay.onclick = function(e) {
    if (e.target === modalOverlay) closeSearchResults();
  };
}

function closeSearchResults() {
  const modal = document.getElementById('searchResultsModal');
  if (modal) modal.remove();
}

/* Modal helpers */
function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove('open');
}

/* Party tabs */
function switchPartyTab(tab, el) {
  document.querySelectorAll('[id^="ptab-"]').forEach(t => t.style.display = 'none');
  const tabEl = document.getElementById('ptab-' + tab);
  if (tabEl) tabEl.style.display = '';
  document.querySelectorAll('#partyNavInner .party-nav-item').forEach(i => i.classList.remove('active'));
  if (el) el.classList.add('active');
}

/* Showcase tabs */
function switchShowcaseTab(tab, el) {
  document.querySelectorAll('[id^="stab-"]').forEach(t => t.style.display = 'none');
  const tabEl = document.getElementById('stab-' + tab);
  if (tabEl) tabEl.style.display = '';
  document.querySelectorAll('#showcaseNavInner .party-nav-item').forEach(i => i.classList.remove('active'));
  if (el) el.classList.add('active');
}

/* Study tabs */
function switchStudyTab(tab, el) {
  document.querySelectorAll('[id^="utab-"]').forEach(t => t.style.display = 'none');
  const tabEl = document.getElementById('utab-' + tab);
  if (tabEl) tabEl.style.display = '';
  document.querySelectorAll('#studyNavInner .party-nav-item').forEach(i => {
    i.classList.remove('active');
    i.style.color = '';
    i.style.borderBottomColor = '';
  });
  if (el) {
    el.classList.add('active');
    el.style.color = 'var(--blue)';
    el.style.borderBottomColor = 'var(--blue)';
  }
}

/* Profile tabs */
function switchProfileTab(tab, el) {
  ['signup', 'study', 'collect', 'achievement', 'download', 'settings'].forEach(t => {
    const tabEl = document.getElementById('ptab-' + t);
    if (tabEl) tabEl.style.display = 'none';
  });
  const tabEl = document.getElementById('ptab-' + tab);
  if (tabEl) tabEl.style.display = '';
  document.querySelectorAll('.profile-tab').forEach(i => i.classList.remove('active'));
  if (el) el.classList.add('active');
}

/* Admin tabs */
function switchAdminPage(page, el) {
  document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
  const pageEl = document.getElementById('admin-' + page);
  if (pageEl) pageEl.classList.add('active');
  document.querySelectorAll('.admin-nav-item').forEach(i => i.classList.remove('active'));
  if (el) el.classList.add('active');
}

/* Hero slider */
let slideIdx = 0;
let slideCount = 3;

function slideHero(dir) {
  slideIdx = (slideIdx + dir + slideCount) % slideCount;
  updateSlider();
}

function goSlide(i) { slideIdx = i; updateSlider(); }

function updateSlider() {
  const slides = document.getElementById('heroSlides');
  if (slides) slides.style.transform = `translateX(-${slideIdx * 100}%)`;
  document.querySelectorAll('.hero-dot').forEach((d, i) => d.classList.toggle('active', i === slideIdx));
}

/* Login */
function doLogin() {
  const u = document.getElementById('loginUser').value;
  const p = document.getElementById('loginPass').value;
  
  const users = [
    { username: 'admin', password: '123456', name: '张明远', role: 'admin' },
    { username: 'user', password: '123456', name: '李小明', role: 'user' }
  ];
  
  const user = users.find(user => user.username === u && user.password === p);
  
  if (user) {
    localStorage.setItem('userLoggedIn', 'true');
    localStorage.setItem('userName', user.name);
    localStorage.setItem('userRole', user.role);
    
    showToast(`✅ 登录成功！欢迎回来，${user.name}`);
    updateNavigation();
    setTimeout(() => { window.location.href = 'index.html'; }, 800);
  } else {
    showToast('❌ 账号或密码错误，请重试');
  }
}

function doGuestLogin() {
  let guestName = localStorage.getItem('guestName');
  if (!guestName) {
    guestName = '访客' + String(Math.floor(1000 + Math.random() * 9000));
    localStorage.setItem('guestName', guestName);
  }
  
  localStorage.setItem('userLoggedIn', 'true');
  localStorage.setItem('userName', guestName);
  localStorage.setItem('userRole', 'guest');
  
  showToast('👤 ' + guestName + ' 登录成功！您可以浏览公开内容');
  setTimeout(() => { window.location.href = 'index.html'; }, 500);
}

function isLoggedIn() { return localStorage.getItem('userLoggedIn') === 'true'; }
function getUserRole() { return localStorage.getItem('userRole') || 'guest'; }
function isAdmin() { return getUserRole() === 'admin'; }
function isGuest() { return getUserRole() === 'guest'; }

/* Page loader */
function hidePageLoader() {
  const loader = document.getElementById('pageLoader');
  if (loader) {
    loader.classList.add('hidden');
    setTimeout(() => loader.remove(), 500);
  }
}

/* Initialize */
document.addEventListener('DOMContentLoaded', function() {
  initTheme();
  initFontSize();
  initNavbarEffects();
  updateNavigation();
  hidePageLoader();
  
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') performSearch();
    });
  }
});
